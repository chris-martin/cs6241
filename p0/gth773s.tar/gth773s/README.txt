opt -load llvm-2.8-build/Release/lib/phase0-gth773s.so -phase0-gth773s -analyze test.bc

