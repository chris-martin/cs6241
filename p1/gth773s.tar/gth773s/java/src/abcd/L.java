package abcd;

enum L {

    False, Reduced, True;

}
