int main(int argc, char **argv) {
  int arr[argc];
  int i = 7;
  if (i < argc) {
    arr[i] = 11;
  }
}

