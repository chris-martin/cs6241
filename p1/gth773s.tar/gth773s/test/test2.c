int main(int argc, char **argv) {
  int arr[argc];
  arr[7] = 11;
  arr[8] = 13;
}

